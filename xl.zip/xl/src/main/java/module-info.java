module xl {
  requires javafx.controls;
  requires java.desktop;
  requires com.google.common;
  exports gui;
  exports model;
  exports expr;
}
