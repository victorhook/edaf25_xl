package util;

import java.io.IOException;

public class XLException extends IOException {
  public XLException(String message) {
    super(message);
  }
}
